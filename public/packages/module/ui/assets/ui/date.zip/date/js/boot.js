$(".datetime").datetimepicker({format: 'yyyy-mm-dd hh:ii'});
